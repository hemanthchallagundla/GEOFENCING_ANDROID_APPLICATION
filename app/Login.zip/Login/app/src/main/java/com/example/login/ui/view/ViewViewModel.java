package com.example.login.ui.view;

import androidx.lifecycle.ViewModel;

public class ViewViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}